function playGame(userChoice) {
    const choices = ['حجر', 'ورقة', 'مقص'];
    const computerChoice = choices[Math.floor(Math.random() * 3)];

    let result;

    if (userChoice === computerChoice) {
        result = 'تعادل!';
    } else if (
        (userChoice === 'حجر' && computerChoice === 'مقص') ||
        (userChoice === 'ورقة' && computerChoice === 'حجر') ||
        (userChoice === 'مقص' && computerChoice === 'ورقة')
    ) {
        result = 'فزت!';
    } else {
        result = 'خسرت!';
    }

    document.getElementById('result').innerHTML = `اختيارك: ${userChoice}، اختيار الكمبيوتر: ${computerChoice} - ${result}`;
}
